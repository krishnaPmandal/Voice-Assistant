package com.voiceassistant.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.voiceassistant.R
import com.voiceassistant.actions.ActionExecutor
import com.voiceassistant.actions.ActionResult
import com.voiceassistant.data.Prefs
import com.voiceassistant.databinding.ActivityOverlayBinding
import com.voiceassistant.nlu.ConversationContext
import com.voiceassistant.nlu.IntentParser
import com.voiceassistant.stt.SpeechEngine
import com.voiceassistant.tts.TtsEngine

/**
 * Overlay activity — launched by long-pressing Home (ASSIST intent).
 * Stays open. Hands-free loop: listen → respond → listen.
 */
class AssistantOverlayActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOverlayBinding
    private lateinit var stt: SpeechEngine
    private lateinit var tts: TtsEngine
    private val handler = Handler(Looper.getMainLooper())

    // Conversation context for pronoun resolution (spec #8)
    private var context = ConversationContext()

    // Pending confirmation (spec #7)
    private var pendingAction: (() -> Unit)? = null
    private var awaitingConfirmation = false

    // WhatsApp multi-select follow-up
    private var pendingFollowUp: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOverlayBinding.inflate(layoutInflater)
        setContentView(binding.root)

        stt = SpeechEngine(this)
        tts = TtsEngine(this)

        binding.tvOverlayName.text = Prefs.getAssistantName(this)
        updateModeLabel()

        // Tap background to dismiss; tap card to keep open
        binding.root.setOnClickListener { finish() }
        binding.overlayCard.setOnClickListener { /* keep open */ }

        // Manual mic tap
        binding.btnMicOverlay.setOnClickListener {
            if (!stt.listening) startListening()
        }

        // Confirmation buttons (spec #7)
        binding.btnConfirmYes.setOnClickListener {
            binding.confirmBar.visibility = android.view.View.GONE
            awaitingConfirmation = false
            val action = pendingAction
            pendingAction = null
            action?.invoke()
            speakThenListen("Done.")
        }
        binding.btnConfirmNo.setOnClickListener {
            binding.confirmBar.visibility = android.view.View.GONE
            awaitingConfirmation = false
            pendingAction = null
            speakThenListen("Cancelled. What else can I help with?")
        }

        handler.postDelayed({ startListening() }, 500)
    }

    override fun onResume() {
        super.onResume()
        if (!stt.listening && !awaitingConfirmation) {
            handler.postDelayed({ if (!stt.listening) startListening() }, 400)
        }
    }

    override fun onPause() {
        super.onPause()
        stt.stopListening()
        binding.overlayWaveform.setActive(false)
        binding.micRippleOverlay.clearAnimation()
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Microphone permission needed", Toast.LENGTH_SHORT).show()
            return
        }
        if (awaitingConfirmation) return

        binding.tvOverlayStatus.text = "Listening"
        binding.tvOverlaySpoken.text = if (pendingFollowUp.isNotBlank()) "Waiting for your choice..." else ""
        binding.overlayWaveform.setActive(true)
        val pulse = AnimationUtils.loadAnimation(this, R.anim.pulse)
        binding.micRippleOverlay.startAnimation(pulse)

        val offline = Prefs.isOfflineMode(this)
        stt.startListening(offline, object : SpeechEngine.Listener {
            override fun onReady() { binding.tvOverlayStatus.text = "Listening" }
            override fun onRmsChanged(rms: Float) {
                binding.overlayWaveform.updateAmplitude((rms / 10f).coerceIn(0f, 1f))
            }
            override fun onPartialResult(text: String) { binding.tvOverlaySpoken.text = text }
            override fun onResult(text: String) {
                stopVisuals()
                handleSpoken(text)
            }
            override fun onError(error: String) {
                stopVisuals()
                val msg = when (error) {
                    "network_error" -> {
                        // Auto-switch to offline on network error (spec #3)
                        "No internet. Switching to offline mode. Please say again."
                    }
                    "no_match", "timeout" -> "Please say again"
                    else -> "Please say again"
                }
                speakThenListen(msg)
            }
        })
    }

    private fun stopVisuals() {
        binding.overlayWaveform.setActive(false)
        binding.micRippleOverlay.clearAnimation()
        binding.tvOverlayStatus.text = "Processing"
    }

    private fun handleSpoken(spoken: String) {
        binding.tvOverlaySpoken.text = "\"$spoken\""

        // WhatsApp follow-up selection
        if (pendingFollowUp.isNotBlank()) {
            val result = resolveFollowUp(spoken)
            pendingFollowUp = ""
            handleResult(spoken, result)
            return
        }

        // Parse intent
        val parsed = IntentParser.parse(spoken, context)
        val result = ActionExecutor.execute(this, parsed)

        // Update conversation context for pronouns (spec #8)
        result.action?.let {
            parsed.entities["contact"]?.let { c ->
                context = context.copy(lastContact = c)
            }
            parsed.entities["app"]?.let { a ->
                context = context.copy(lastApp = a)
            }
        }

        handleResult(spoken, result)
    }

    private fun handleResult(spoken: String, result: ActionResult) {
        // Save history
        Prefs.saveHistory(this, spoken, result.reply)

        // Clean reply (remove emojis)
        val cleanReply = result.reply.replace(Regex("[^\\p{L}\\p{N}\\p{P}\\p{Z}\\n]"), "").trim()
        binding.tvOverlayResponse.text = cleanReply

        // Spec #7: confirmation needed?
        if (result.needsConfirmation) {
            awaitingConfirmation = true
            pendingAction = result.pendingAction
            binding.confirmBar.visibility = android.view.View.VISIBLE
            tts.onDone = null
            tts.speak(cleanReply)
            return
        }

        // Follow-up needed (e.g. WhatsApp selection)?
        if (result.needsFollowUp) {
            pendingFollowUp = result.followUpPrompt
        }

        speakThenListen(cleanReply, result.action)
    }

    private fun speakThenListen(text: String, action: (() -> Unit)? = null) {
        tts.onDone = {
            handler.post {
                action?.invoke()
                handler.postDelayed({ if (!stt.listening && !awaitingConfirmation) startListening() }, 700)
            }
        }
        tts.speak(text)
    }

    private fun resolveFollowUp(spoken: String): ActionResult {
        if (pendingFollowUp.startsWith("wa_select:")) {
            val appsRaw = pendingFollowUp.removePrefix("wa_select:")
            val allApps = appsRaw.split(",").mapNotNull {
                val s = it.split("|"); if (s.size == 2) Pair(s[0], s[1]) else null
            }
            val lower = spoken.lowercase()
            val selected = allApps.firstOrNull { lower.contains(it.first.lowercase()) }
                ?: allApps.firstOrNull { lower.contains("second") || lower.contains("two") }?.let { allApps.getOrNull(1) }
                ?: allApps.first()
            return ActionResult(
                reply = "Opening ${selected.first}",
                action = {
                    val intent = packageManager.getLaunchIntentForPackage(selected.second)
                        ?: android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("whatsapp://send"))
                    intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                }
            )
        }
        return ActionResult(reply = "Sorry, I lost track. What would you like to do?")
    }

    private fun updateModeLabel() {
        val offline = Prefs.isOfflineMode(this)
        binding.tvMode.text = if (offline) "Offline" else "Online"
        binding.tvMode.setTextColor(
            if (offline) getColor(com.voiceassistant.R.color.orange_offline)
            else getColor(com.voiceassistant.R.color.green_online)
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        stt.destroy()
        tts.shutdown()
    }
}
