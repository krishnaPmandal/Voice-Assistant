package com.voiceassistant.ui

import android.app.Activity
import android.os.Bundle

/** Transparent shim for runtime permission requests from non-Activity contexts */
class PermissionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        finish()
    }
}
