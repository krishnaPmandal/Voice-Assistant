package com.voiceassistant.nlu

/**
 * All supported intents the assistant can recognise.
 * Adding a new capability = add an enum value + rules in IntentParser.
 */
enum class IntentType {
    CALL,
    SEND_SMS,
    OPEN_APP,
    SEARCH_GOOGLE,
    SEARCH_YOUTUBE,
    PLAY_MUSIC,
    SET_ALARM,
    OPEN_SETTINGS,
    GET_TIME,
    GET_DATE,
    TELL_JOKE,
    UNKNOWN
}

/**
 * Result of NLU parsing: what the user wants + extracted entities.
 * entities map holds things like "contact" -> "John", "time" -> "7", "query" -> "weather"
 */
data class ParsedIntent(
    val type: IntentType,
    val entities: Map<String, String> = emptyMap(),
    val rawInput: String = "",
    val confidence: Float = 1f
)
