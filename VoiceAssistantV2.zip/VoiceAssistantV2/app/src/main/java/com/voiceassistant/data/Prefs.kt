package com.voiceassistant.data

import android.content.Context
import androidx.core.content.edit

/** Central preference store — all settings live here */
object Prefs {
    private const val NAME = "va_prefs"

    fun getAssistantName(ctx: Context) =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString("assistant_name", "Assistant") ?: "Assistant"

    fun setAssistantName(ctx: Context, name: String) =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit { putString("assistant_name", name) }

    fun isOfflineMode(ctx: Context) =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getBoolean("offline_mode", false)

    fun setOfflineMode(ctx: Context, v: Boolean) =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit { putBoolean("offline_mode", v) }

    fun isConfirmCalls(ctx: Context) =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getBoolean("confirm_calls", true)

    fun setConfirmCalls(ctx: Context, v: Boolean) =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit { putBoolean("confirm_calls", v) }

    fun isConfirmSms(ctx: Context) =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getBoolean("confirm_sms", true)

    fun setConfirmSms(ctx: Context, v: Boolean) =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit { putBoolean("confirm_sms", v) }

    fun saveHistory(ctx: Context, command: String, reply: String) {
        val prefs = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        val existing = prefs.getString("history", "") ?: ""
        val entry = "${System.currentTimeMillis()}|||$command|||$reply\n"
        val updated = (entry + existing).lines().take(60).joinToString("\n")
        prefs.edit { putString("history", updated) }
    }

    fun getHistory(ctx: Context): List<Triple<Long, String, String>> {
        val raw = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString("history", "") ?: ""
        return raw.lines().filter { it.isNotBlank() }.mapNotNull {
            val p = it.split("|||")
            if (p.size == 3) Triple(p[0].toLongOrNull() ?: 0L, p[1], p[2]) else null
        }
    }

    fun clearHistory(ctx: Context) =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit { remove("history") }
}
