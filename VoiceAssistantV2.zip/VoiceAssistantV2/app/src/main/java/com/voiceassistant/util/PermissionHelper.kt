package com.voiceassistant.util

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Permission helper — spec item 5.
 * Request only when needed, explain why, handle denial gracefully.
 */
object PermissionHelper {

    val MICROPHONE = Manifest.permission.RECORD_AUDIO
    val CONTACTS   = Manifest.permission.READ_CONTACTS
    val CALL_PHONE = Manifest.permission.CALL_PHONE

    fun hasPermission(ctx: Context, permission: String) =
        ContextCompat.checkSelfPermission(ctx, permission) == PackageManager.PERMISSION_GRANTED

    fun hasMic(ctx: Context) = hasPermission(ctx, MICROPHONE)
    fun hasContacts(ctx: Context) = hasPermission(ctx, CONTACTS)
    fun hasCallPhone(ctx: Context) = hasPermission(ctx, CALL_PHONE)

    fun requestMic(activity: Activity, requestCode: Int = 100) =
        ActivityCompat.requestPermissions(activity, arrayOf(MICROPHONE), requestCode)

    fun requestContacts(activity: Activity, requestCode: Int = 101) =
        ActivityCompat.requestPermissions(activity, arrayOf(CONTACTS), requestCode)

    fun requestCall(activity: Activity, requestCode: Int = 102) =
        ActivityCompat.requestPermissions(activity, arrayOf(CALL_PHONE), requestCode)

    /** Returns a human-friendly reason for each permission — spec item 5. */
    fun getRationale(permission: String) = when (permission) {
        MICROPHONE -> "Microphone access is needed to hear your voice commands."
        CONTACTS   -> "Contacts access lets you call and message people by name."
        CALL_PHONE -> "Phone permission is required to make calls on your behalf."
        else       -> "This permission is required for the assistant to work."
    }
}
