package com.voiceassistant.nlu

import java.util.Locale

/**
 * NLU engine — maps free-form natural language to structured intents.
 *
 * Design:
 * - Rule-based pattern matching (no server needed, instant, offline-safe)
 * - Entity extraction via named regex groups
 * - Handles multiple phrasings for the same intent
 * - Context-aware pronoun resolution (short-term memory passed in)
 */
object IntentParser {

    // Short-term conversation context
    private var lastContact: String = ""
    private var lastApp: String = ""

    /** Parse raw speech into a structured intent */
    fun parse(input: String, context: ConversationContext = ConversationContext()): ParsedIntent {
        val raw = input.trim()
        val lower = raw.lowercase(Locale.ROOT)

        // ── CALL ─────────────────────────────────────────────────────
        // "call John" / "give John a ring" / "can you call John?" / "phone Mom"
        val callPatterns = listOf(
            Regex("""(?:call|phone|ring|dial|give .+ a (?:call|ring))\s+(?:up\s+)?([a-zA-Z\s]+?)(?:\s*$|\s+(?:for me|please|now))"""),
            Regex("""(?:can you|please|would you)?\s*(?:call|phone|ring|dial)\s+([a-zA-Z\s]+?)(?:\s*$|\s+(?:for me|please|now))"""),
            Regex("""(?:i want to|i'd like to)\s+(?:call|talk to|speak to|speak with)\s+([a-zA-Z\s]+?)(?:\s*$|\s+(?:for me|please))""")
        )
        for (p in callPatterns) {
            val m = p.find(lower) ?: continue
            val contact = resolveContact(m.groupValues[1].trim(), context)
            if (contact.isNotBlank()) {
                lastContact = contact
                return ParsedIntent(IntentType.CALL, mapOf("contact" to contact), raw)
            }
        }

        // ── SMS ───────────────────────────────────────────────────────
        // "send message to John saying hello" / "text Mom I'll be late"
        val smsPatterns = listOf(
            Regex("""(?:send|write|text|message)\s+(?:a\s+)?(?:message|text|msg)?\s+to\s+([a-zA-Z\s]+?)\s+(?:saying|that|:)\s+(.+)$"""),
            Regex("""(?:text|message)\s+([a-zA-Z\s]+?)\s+(?:saying|that|:)\s+(.+)$"""),
            Regex("""(?:tell|let)\s+([a-zA-Z\s]+?)\s+(?:that|:)?\s+(.+)$""")
        )
        for (p in smsPatterns) {
            val m = p.find(lower) ?: continue
            val contact = resolveContact(m.groupValues[1].trim(), context)
            val msg = m.groupValues[2].trim()
            if (contact.isNotBlank()) {
                lastContact = contact
                return ParsedIntent(IntentType.SEND_SMS, mapOf("contact" to contact, "message" to msg), raw)
            }
        }

        // ── YOUTUBE SEARCH ────────────────────────────────────────────
        if (lower.containsAny("youtube", "watch", "video")) {
            val query = lower
                .replace(Regex("\\b(search|find|look up|play|on youtube|youtube|video|watch|show me|the)\\b"), " ")
                .trim().consolidate()
            if (query.isNotBlank())
                return ParsedIntent(IntentType.SEARCH_YOUTUBE, mapOf("query" to query), raw)
        }

        // ── PLAY MUSIC ────────────────────────────────────────────────
        if (lower.containsAny("play", "music", "song", "songs", "listen to")) {
            val query = lower
                .replace(Regex("\\b(play|music|song|songs|listen to|put on|the|please|me|can you|audio)\\b"), " ")
                .trim().consolidate()
            return ParsedIntent(IntentType.PLAY_MUSIC, mapOf("query" to query), raw)
        }

        // ── ALARM ─────────────────────────────────────────────────────
        if (lower.containsAny("alarm", "wake me", "wake up", "reminder", "remind me")) {
            val timeMap = extractTime(lower)
            return ParsedIntent(IntentType.SET_ALARM, timeMap, raw)
        }

        // ── GOOGLE SEARCH ─────────────────────────────────────────────
        if (lower.containsAny("search", "google", "look up", "find", "what is", "who is", "where is", "how to", "tell me about")) {
            val query = lower
                .replace(Regex("\\b(search|google|look up|find|what is|who is|where is|how to|tell me about|on google|for|the|please|in|show me)\\b"), " ")
                .trim().consolidate()
            return ParsedIntent(IntentType.SEARCH_GOOGLE, mapOf("query" to query), raw)
        }

        // ── SETTINGS ─────────────────────────────────────────────────
        if (lower.containsAny("setting", "settings", "wifi", "bluetooth", "accessibility")) {
            val sub = when {
                lower.contains("wifi") || lower.contains("wi-fi") -> "wifi"
                lower.contains("bluetooth") -> "bluetooth"
                lower.contains("display") || lower.contains("brightness") -> "display"
                lower.contains("sound") || lower.contains("volume") -> "sound"
                lower.contains("battery") -> "battery"
                lower.contains("accessibility") -> "accessibility"
                else -> "main"
            }
            return ParsedIntent(IntentType.OPEN_SETTINGS, mapOf("sub" to sub), raw)
        }

        // ── OPEN APP ─────────────────────────────────────────────────
        if (lower.containsAny("open", "launch", "start", "go to", "take me to", "switch to", "show")) {
            val appName = lower
                .replace(Regex("\\b(open|launch|start|go to|take me to|switch to|show|please|the|app|me)\\b"), " ")
                .trim().consolidate()
            if (appName.isNotBlank()) {
                lastApp = appName
                return ParsedIntent(IntentType.OPEN_APP, mapOf("app" to appName), raw)
            }
        }

        // ── TIME ─────────────────────────────────────────────────────
        if (lower.containsAny("what time", "time is it", "current time", "what's the time")) {
            return ParsedIntent(IntentType.GET_TIME, emptyMap(), raw)
        }

        // ── DATE ─────────────────────────────────────────────────────
        if (lower.containsAny("what day", "what date", "today's date", "what's today")) {
            return ParsedIntent(IntentType.GET_DATE, emptyMap(), raw)
        }

        // ── JOKE ─────────────────────────────────────────────────────
        if (lower.containsAny("joke", "funny", "make me laugh", "tell me a joke")) {
            return ParsedIntent(IntentType.TELL_JOKE, emptyMap(), raw)
        }

        // ── KNOWN APPS (direct name mention without "open") ──────────
        val knownApps = listOf("instagram","facebook","twitter","telegram","spotify",
            "camera","gallery","maps","gmail","chrome","calculator",
            "clock","calendar","netflix","snapchat","gpay","paytm","phonepe",
            "zomato","swiggy","flipkart","amazon","youtube","whatsapp")
        val foundApp = knownApps.firstOrNull { lower.contains(it) }
        if (foundApp != null) {
            return ParsedIntent(IntentType.OPEN_APP, mapOf("app" to foundApp), raw)
        }

        return ParsedIntent(IntentType.UNKNOWN, emptyMap(), raw, 0f)
    }

    /** Resolve pronouns ("her", "him", "them") to last known contact */
    private fun resolveContact(raw: String, ctx: ConversationContext): String {
        return when (raw.trim().lowercase()) {
            "her", "she", "him", "he", "them", "they" ->
                ctx.lastContact.ifBlank { lastContact }.ifBlank { raw }
            else -> raw
        }
    }

    /** Extract hour/minute/ampm from text */
    fun extractTime(text: String): Map<String, String> {
        val patterns = listOf(
            Regex("""(\d{1,2}):(\d{2})\s*(am|pm)?"""),
            Regex("""(\d{1,2})\s*(am|pm)"""),
            Regex("""(?:alarm|wake|reminder|for|at).*?(\d{1,2})\b""")
        )
        for (pattern in patterns) {
            val m = pattern.find(text) ?: continue
            val rawHour = m.groupValues[1].toIntOrNull() ?: continue
            val minute = m.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
            val suffix = (m.groupValues.getOrNull(3) ?: m.groupValues.getOrNull(2) ?: "").lowercase()
            val hour = when {
                suffix == "pm" && rawHour < 12 -> rawHour + 12
                suffix == "am" && rawHour == 12 -> 0
                suffix.isEmpty() && rawHour in 1..6 -> rawHour + 12
                else -> rawHour
            }
            val displayHour = when { hour == 0 -> 12; hour > 12 -> hour - 12; else -> hour }
            val amPm = if (hour >= 12) "PM" else "AM"
            val display = "$displayHour${if (minute > 0) ":${minute.toString().padStart(2,'0')}" else ""} $amPm"
            return mapOf("hour" to hour.toString(), "minute" to minute.toString(), "display" to display)
        }
        return emptyMap()
    }

    private fun String.containsAny(vararg kw: String) = kw.any { this.contains(it) }
    private fun String.consolidate() = this.replace(Regex("\\s+"), " ").trim()
}

/** Short-term conversation context passed between turns */
data class ConversationContext(
    val lastContact: String = "",
    val lastApp: String = "",
    val lastAction: String = ""
)
