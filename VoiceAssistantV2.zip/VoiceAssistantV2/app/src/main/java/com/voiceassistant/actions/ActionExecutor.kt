package com.voiceassistant.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import android.telephony.SmsManager
import com.voiceassistant.data.Prefs
import com.voiceassistant.nlu.IntentParser
import com.voiceassistant.nlu.IntentType
import com.voiceassistant.nlu.ParsedIntent
import java.util.Calendar
import java.util.Locale

/**
 * Executes parsed intents and returns an ActionResult.
 * This is the only place that performs real device actions.
 */
object ActionExecutor {

    fun execute(context: Context, intent: ParsedIntent): ActionResult {
        return when (intent.type) {

            IntentType.CALL -> executeCall(context, intent)
            IntentType.SEND_SMS -> executeSms(context, intent)
            IntentType.OPEN_APP -> executeOpenApp(context, intent)
            IntentType.SEARCH_GOOGLE -> executeSearchGoogle(context, intent)
            IntentType.SEARCH_YOUTUBE -> executeSearchYoutube(context, intent)
            IntentType.PLAY_MUSIC -> executePlayMusic(context, intent)
            IntentType.SET_ALARM -> executeSetAlarm(context, intent)
            IntentType.OPEN_SETTINGS -> executeOpenSettings(context, intent)
            IntentType.GET_TIME -> getTime()
            IntentType.GET_DATE -> getDate()
            IntentType.TELL_JOKE -> tellJoke()

            IntentType.UNKNOWN -> ActionResult(
                reply = "I did not catch that. Try saying: call someone, set an alarm, play a song, or search on Google."
            )
        }
    }

    // ── CALL ────────────────────────────────────────────────────────
    private fun executeCall(context: Context, intent: ParsedIntent): ActionResult {
        val contactName = intent.entities["contact"] ?: ""
        if (contactName.isBlank()) {
            return ActionResult(reply = "Who should I call? Please say a name.")
        }

        val contact = ContactResolver.findContact(context, contactName)
        val confirmCalls = Prefs.isConfirmCalls(context)

        return if (contact != null) {
            val callAction = {
                val callIntent = Intent(Intent.ACTION_CALL, Uri.parse("tel:${contact.number}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    context.startActivity(callIntent)
                } catch (e: Exception) {
                    // Fallback to dial screen if CALL_PHONE permission denied
                    context.startActivity(
                        Intent(Intent.ACTION_DIAL, Uri.parse("tel:${contact.number}")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                    )
                }
            }

            if (confirmCalls) {
                ActionResult(
                    reply = "Calling ${contact.name}. Should I proceed?",
                    needsConfirmation = true,
                    confirmationPrompt = "Call ${contact.name} at ${contact.number}?",
                    pendingAction = callAction
                )
            } else {
                ActionResult(reply = "Calling ${contact.name}", action = callAction)
            }
        } else {
            // Contact not found — try to be helpful
            val candidates = ContactResolver.findCandidates(context, contactName)
            if (candidates.isNotEmpty()) {
                val names = candidates.take(2).joinToString(" or ") { it.name }
                ActionResult(
                    reply = "I could not find $contactName. Did you mean $names? Say the name again.",
                    needsFollowUp = true,
                    followUpPrompt = "call_retry"
                )
            } else {
                ActionResult(
                    reply = "I could not find a contact named $contactName. Please check the name and try again."
                )
            }
        }
    }

    // ── SMS ─────────────────────────────────────────────────────────
    private fun executeSms(context: Context, intent: ParsedIntent): ActionResult {
        val contactName = intent.entities["contact"] ?: ""
        val message = intent.entities["message"] ?: ""

        if (contactName.isBlank()) return ActionResult(reply = "Who should I send the message to?")
        if (message.isBlank()) return ActionResult(reply = "What should the message say?")

        val contact = ContactResolver.findContact(context, contactName)
            ?: return ActionResult(reply = "I could not find a contact named $contactName.")

        val smsAction = {
            try {
                val smsManager = context.getSystemService(SmsManager::class.java)
                smsManager.sendTextMessage(contact.number, null, message, null, null)
            } catch (e: Exception) {
                // Fallback: open SMS app
                context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("sms:${contact.number}")
                    putExtra("sms_body", message)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            }
        }

        return if (Prefs.isConfirmSms(context)) {
            ActionResult(
                reply = "Sending to ${contact.name}: $message. Should I proceed?",
                needsConfirmation = true,
                confirmationPrompt = "Send: \"$message\" to ${contact.name}?",
                pendingAction = smsAction
            )
        } else {
            ActionResult(reply = "Message sent to ${contact.name}", action = smsAction)
        }
    }

    // ── OPEN APP ────────────────────────────────────────────────────
    private fun executeOpenApp(context: Context, intent: ParsedIntent): ActionResult {
        val appName = intent.entities["app"] ?: ""
        if (appName.isBlank()) return ActionResult(reply = "Which app should I open?")

        // Special case: WhatsApp with clones
        if (appName.contains("whatsapp")) {
            val waApps = AppLauncher.getInstalledWhatsApps(context)
            if (waApps.size > 1) {
                val names = waApps.joinToString(" or ") { it.first }
                return ActionResult(
                    reply = "Which WhatsApp? $names",
                    needsFollowUp = true,
                    followUpPrompt = "wa_select:${waApps.joinToString(",") { "${it.first}|${it.second}" }}"
                )
            }
        }

        return ActionResult(
            reply = "Opening ${appName.replaceFirstChar { it.uppercase() }}",
            action = { AppLauncher.launch(context, appName) }
        )
    }

    // ── SEARCH GOOGLE ───────────────────────────────────────────────
    private fun executeSearchGoogle(context: Context, intent: ParsedIntent): ActionResult {
        val query = intent.entities["query"] ?: ""
        if (query.isBlank()) return ActionResult(reply = "What should I search for?")
        return ActionResult(
            reply = "Searching Google for $query",
            action = {
                try {
                    context.startActivity(Intent(Intent.ACTION_WEB_SEARCH).apply {
                        putExtra("query", query)
                        setPackage("com.google.android.googlequicksearchbox")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                } catch (e: Exception) {
                    try {
                        context.startActivity(Intent(Intent.ACTION_WEB_SEARCH).apply {
                            putExtra("query", query)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        })
                    } catch (e2: Exception) {
                        context.startActivity(Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        })
                    }
                }
            }
        )
    }

    // ── SEARCH YOUTUBE ──────────────────────────────────────────────
    private fun executeSearchYoutube(context: Context, intent: ParsedIntent): ActionResult {
        val query = intent.entities["query"] ?: ""
        if (query.isBlank()) return ActionResult(reply = "What should I search on YouTube?")
        return ActionResult(
            reply = "Searching YouTube for $query",
            action = {
                val i = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try { i.setPackage("com.google.android.youtube"); context.startActivity(i) }
                catch (e: Exception) { i.setPackage(null); context.startActivity(i) }
            }
        )
    }

    // ── PLAY MUSIC ──────────────────────────────────────────────────
    private fun executePlayMusic(context: Context, intent: ParsedIntent): ActionResult {
        val query = intent.entities["query"] ?: ""
        val reply = if (query.isNotBlank()) "Playing $query from YouTube" else "Opening YouTube Music"
        return ActionResult(
            reply = reply,
            action = {
                val url = if (query.isNotBlank())
                    "https://www.youtube.com/results?search_query=${Uri.encode(query)}"
                else "https://music.youtube.com"
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try { i.setPackage("com.google.android.youtube"); context.startActivity(i) }
                catch (e: Exception) { i.setPackage(null); context.startActivity(i) }
            }
        )
    }

    // ── SET ALARM ───────────────────────────────────────────────────
    private fun executeSetAlarm(context: Context, intent: ParsedIntent): ActionResult {
        val hour = intent.entities["hour"]?.toIntOrNull()
        val minute = intent.entities["minute"]?.toIntOrNull() ?: 0
        val display = intent.entities["display"]

        return if (hour != null && display != null) {
            ActionResult(
                reply = "Opening alarm for $display",
                action = {
                    var done = false
                    try {
                        context.startActivity(Intent(AlarmClock.ACTION_SET_ALARM).apply {
                            putExtra(AlarmClock.EXTRA_HOUR, hour)
                            putExtra(AlarmClock.EXTRA_MINUTES, minute)
                            putExtra(AlarmClock.EXTRA_MESSAGE, "Assistant Alarm")
                            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        })
                        done = true
                    } catch (_: Exception) {}

                    if (!done) {
                        for (pkg in listOf("com.vivo.deskclock","com.bbk.deskclock","com.android.deskclock")) {
                            val i = context.packageManager.getLaunchIntentForPackage(pkg)
                            if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(i); break }
                        }
                    }
                }
            )
        } else {
            ActionResult(reply = "What time should I set the alarm for? Say for example, set alarm for 7 AM.")
        }
    }

    // ── OPEN SETTINGS ───────────────────────────────────────────────
    private fun executeOpenSettings(context: Context, intent: ParsedIntent): ActionResult {
        val sub = intent.entities["sub"] ?: "main"
        val settingsIntent = when (sub) {
            "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "sound" -> Intent(Settings.ACTION_SOUND_SETTINGS)
            "battery" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            else -> Intent(Settings.ACTION_SETTINGS)
        }
        return ActionResult(
            reply = "Opening ${if (sub == "main") "settings" else "$sub settings"}",
            action = {
                context.startActivity(settingsIntent.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            }
        )
    }

    // ── TIME ────────────────────────────────────────────────────────
    private fun getTime(): ActionResult {
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR).let { if (it == 0) 12 else it }
        val min = cal.get(Calendar.MINUTE).toString().padStart(2, '0')
        val amPm = if (cal.get(Calendar.AM_PM) == Calendar.AM) "AM" else "PM"
        return ActionResult(reply = "It is $hour:$min $amPm")
    }

    // ── DATE ────────────────────────────────────────────────────────
    private fun getDate(): ActionResult {
        val cal = Calendar.getInstance()
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val month = cal.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.ENGLISH) ?: ""
        val weekday = cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.ENGLISH) ?: ""
        val year = cal.get(Calendar.YEAR)
        return ActionResult(reply = "Today is $weekday, $day $month $year")
    }

    // ── JOKE ────────────────────────────────────────────────────────
    private fun tellJoke(): ActionResult {
        val jokes = listOf(
            "Why don't scientists trust atoms? Because they make up everything.",
            "I told my wife she was drawing her eyebrows too high. She looked surprised.",
            "Why did the phone go to therapy? It had too many hang-ups.",
            "What do you call a fake noodle? An impasta.",
            "Why can't you give Elsa a balloon? Because she will let it go.",
            "I asked my dog what two minus two is. He said nothing.",
            "Why do programmers prefer dark mode? Because light attracts bugs."
        )
        return ActionResult(reply = jokes.random())
    }
}
