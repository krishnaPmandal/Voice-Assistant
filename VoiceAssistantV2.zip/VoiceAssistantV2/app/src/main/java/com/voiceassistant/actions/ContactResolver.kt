package com.voiceassistant.actions

import android.content.Context
import android.provider.ContactsContract

/** Looks up phone numbers from the contacts database */
object ContactResolver {

    data class Contact(val name: String, val number: String)

    /**
     * Find best matching contact for a spoken name.
     * Returns null if not found or no READ_CONTACTS permission.
     */
    fun findContact(context: Context, spokenName: String): Contact? {
        return try {
            val lower = spokenName.lowercase().trim()
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val proj = arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            val cursor = context.contentResolver.query(uri, proj, null, null, null)
                ?: return null

            var bestMatch: Contact? = null
            var bestScore = 0

            cursor.use {
                while (it.moveToNext()) {
                    val name = it.getString(0) ?: continue
                    val number = it.getString(1) ?: continue
                    val nameLower = name.lowercase()

                    val score = when {
                        nameLower == lower -> 100
                        nameLower.startsWith(lower) -> 80
                        lower.split(" ").all { part -> nameLower.contains(part) } -> 60
                        nameLower.contains(lower) -> 40
                        // Fuzzy: spoken name is contained in contact name
                        lower.split(" ").any { part -> nameLower.contains(part) && part.length > 2 } -> 20
                        else -> 0
                    }

                    if (score > bestScore) {
                        bestScore = score
                        bestMatch = Contact(name, number)
                    }
                }
            }

            if (bestScore >= 20) bestMatch else null
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Find multiple possible matches (for disambiguation).
     */
    fun findCandidates(context: Context, spokenName: String, limit: Int = 3): List<Contact> {
        return try {
            val lower = spokenName.lowercase().trim()
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val proj = arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            val cursor = context.contentResolver.query(uri, proj, null, null, null)
                ?: return emptyList()

            val results = mutableListOf<Pair<Contact, Int>>()
            cursor.use {
                while (it.moveToNext()) {
                    val name = it.getString(0) ?: continue
                    val number = it.getString(1) ?: continue
                    val nameLower = name.lowercase()
                    val score = when {
                        nameLower == lower -> 100
                        nameLower.startsWith(lower) -> 80
                        lower.split(" ").all { p -> nameLower.contains(p) } -> 60
                        nameLower.contains(lower) -> 40
                        lower.split(" ").any { p -> nameLower.contains(p) && p.length > 2 } -> 20
                        else -> 0
                    }
                    if (score > 0) results.add(Pair(Contact(name, number), score))
                }
            }

            results.sortedByDescending { it.second }.take(limit).map { it.first }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
