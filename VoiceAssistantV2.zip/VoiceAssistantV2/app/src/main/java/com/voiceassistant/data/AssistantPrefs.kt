package com.voiceassistant.data

import android.content.Context
import androidx.core.content.edit

/** Centralised SharedPreferences wrapper. */
object AssistantPrefs {
    private const val NAME = "va_prefs"

    fun getAssistantName(ctx: Context): String =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString("assistant_name", "Assistant") ?: "Assistant"

    fun setAssistantName(ctx: Context, name: String) =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit { putString("assistant_name", name) }

    fun getTheme(ctx: Context): String =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString("app_theme", "glass") ?: "glass"

    fun setTheme(ctx: Context, theme: String) =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit { putString("app_theme", theme) }

    fun saveHistory(ctx: Context, command: String, reply: String) {
        val prefs = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        val existing = prefs.getString("history", "") ?: ""
        val entry = "${System.currentTimeMillis()}|||$command|||$reply\n"
        val updated = (entry + existing).lines().take(100).joinToString("\n")
        prefs.edit { putString("history", updated) }
    }

    fun getHistory(ctx: Context): List<Triple<Long, String, String>> =
        (ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString("history", "") ?: "")
            .lines().filter { it.isNotBlank() }.mapNotNull {
                val p = it.split("|||")
                if (p.size == 3) Triple(p[0].toLongOrNull() ?: 0L, p[1], p[2]) else null
            }

    fun clearHistory(ctx: Context) =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit { remove("history") }

    // Conversation context for pronoun resolution (#8 in spec)
    fun setLastContact(ctx: Context, name: String) =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit { putString("last_contact", name) }

    fun getLastContact(ctx: Context): String =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString("last_contact", "") ?: ""
}
