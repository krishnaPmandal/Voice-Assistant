package com.voiceassistant.ui

import android.Manifest
import android.animation.ObjectAnimator
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.voiceassistant.R
import com.voiceassistant.actions.ActionExecutor
import com.voiceassistant.actions.ActionResult
import com.voiceassistant.data.Prefs
import com.voiceassistant.databinding.ActivityMainBinding
import com.voiceassistant.nlu.ConversationContext
import com.voiceassistant.nlu.IntentParser
import com.voiceassistant.stt.SpeechEngine
import com.voiceassistant.tts.TtsEngine

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var stt: SpeechEngine
    private lateinit var tts: TtsEngine
    private val handler = Handler(Looper.getMainLooper())
    private var conversationContext = ConversationContext()
    private var pendingAction: (() -> Unit)? = null
    private var awaitingConfirmation = false
    private var pendingFollowUp: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        stt = SpeechEngine(this)
        tts = TtsEngine(this)

        setupUI()
        checkAndRequestPermissions()
        refreshLabels()
    }

    override fun onResume() {
        super.onResume()
        refreshLabels()
        if (!stt.listening && !awaitingConfirmation) {
            handler.postDelayed({ if (!stt.listening) startListening() }, 500)
        }
    }

    override fun onPause() {
        super.onPause()
        stt.stopListening()
        setMicIdle()
    }

    private fun setupUI() {
        binding.btnMic.setOnClickListener {
            if (stt.listening) { stt.stopListening(); setMicIdle() } else startListening()
        }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun refreshLabels() {
        binding.tvAssistantName.text = Prefs.getAssistantName(this)
        val offline = Prefs.isOfflineMode(this)
        binding.tvMode.text = if (offline) "Offline" else "Online"
        binding.tvMode.setTextColor(
            if (offline) getColor(R.color.orange_offline) else getColor(R.color.green_online)
        )
    }

    private fun checkAndRequestPermissions() {
        val needed = mutableListOf<String>()
        val perms = listOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS
        )
        perms.forEach { if (ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED) needed.add(it) }
        if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), 100)
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            binding.tvCommandText.text = "Microphone permission needed"
            return
        }
        if (awaitingConfirmation) return

        binding.btnMic.setBackgroundResource(R.drawable.mic_bg_active)
        binding.tvStatus.text = "Listening"
        binding.tvCommandText.text = if (pendingFollowUp.isNotBlank()) "Waiting for your answer..." else "Speak now"
        binding.waveformView.setActive(true)
        binding.micRipple.startAnimation(AnimationUtils.loadAnimation(this, R.anim.pulse))

        stt.startListening(Prefs.isOfflineMode(this), object : SpeechEngine.Listener {
            override fun onReady() { binding.tvStatus.text = "Listening" }
            override fun onRmsChanged(rms: Float) {
                binding.waveformView.updateAmplitude((rms / 10f).coerceIn(0f, 1f))
            }
            override fun onPartialResult(text: String) { binding.tvCommandText.text = "\"$text\"" }
            override fun onResult(text: String) {
                setMicIdle()
                handleSpoken(text)
            }
            override fun onError(error: String) {
                setMicIdle()
                val msg = if (error == "network_error") "No internet. Switching to offline mode. Please say again."
                          else "Please say again"
                speakThenListen(msg)
            }
        })
    }

    private fun setMicIdle() {
        binding.btnMic.setBackgroundResource(R.drawable.mic_bg_idle)
        binding.micRipple.clearAnimation()
        binding.waveformView.setActive(false)
        binding.tvStatus.text = "Ready"
    }

    private fun handleSpoken(spoken: String) {
        binding.tvCommandText.text = "\"$spoken\""
        binding.tvStatus.text = "Processing"

        if (pendingFollowUp.isNotBlank()) {
            val result = resolveFollowUp(spoken)
            pendingFollowUp = ""
            handleResult(spoken, result)
            return
        }

        val parsed = IntentParser.parse(spoken, conversationContext)
        val result = ActionExecutor.execute(this, parsed)

        parsed.entities["contact"]?.let { conversationContext = conversationContext.copy(lastContact = it) }
        parsed.entities["app"]?.let { conversationContext = conversationContext.copy(lastApp = it) }

        handleResult(spoken, result)
    }

    private fun handleResult(spoken: String, result: ActionResult) {
        Prefs.saveHistory(this, spoken, result.reply)
        val cleanReply = result.reply.replace(Regex("[^\\p{L}\\p{N}\\p{P}\\p{Z}\\n]"), "").trim()
        showResponse(cleanReply)

        if (result.needsConfirmation) {
            awaitingConfirmation = true
            pendingAction = result.pendingAction
            tts.onDone = null
            tts.speak(cleanReply)
            return
        }

        if (result.needsFollowUp) pendingFollowUp = result.followUpPrompt
        speakThenListen(cleanReply, result.action)
    }

    private fun speakThenListen(text: String, action: (() -> Unit)? = null) {
        tts.onDone = {
            handler.post {
                action?.invoke()
                handler.postDelayed({ if (!stt.listening && !awaitingConfirmation) startListening() }, 700)
            }
        }
        tts.speak(text)
    }

    private fun showResponse(text: String) {
        binding.responseCard.visibility = View.VISIBLE
        binding.tvResponse.text = text
        ObjectAnimator.ofFloat(binding.responseCard, "alpha", 0f, 1f).apply { duration = 300 }.start()
    }

    private fun resolveFollowUp(spoken: String): ActionResult {
        if (pendingFollowUp.startsWith("wa_select:")) {
            val appsRaw = pendingFollowUp.removePrefix("wa_select:")
            val allApps = appsRaw.split(",").mapNotNull {
                val s = it.split("|"); if (s.size == 2) Pair(s[0], s[1]) else null
            }
            val lower = spoken.lowercase()
            val selected = allApps.firstOrNull { lower.contains(it.first.lowercase()) } ?: allApps.first()
            return com.voiceassistant.actions.ActionResult(
                reply = "Opening ${selected.first}",
                action = {
                    val intent = packageManager.getLaunchIntentForPackage(selected.second)
                        ?: Intent(Intent.ACTION_VIEW, android.net.Uri.parse("whatsapp://send"))
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                }
            )
        }
        return com.voiceassistant.actions.ActionResult(reply = "Sorry, what would you like to do?")
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        stt.destroy()
        tts.shutdown()
    }
}
