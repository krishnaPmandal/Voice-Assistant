package com.voiceassistant.actions

import android.content.Context
import android.database.Cursor
import android.provider.ContactsContract

/**
 * Fuzzy contact lookup — spec item 9: "Did you mean John?" style recovery.
 * Caches contacts for fast repeat lookups — spec item 11.
 */
object ContactsHelper {

    data class Contact(val name: String, val phone: String)

    private var cache: List<Contact>? = null

    fun findContact(ctx: Context, query: String): Contact? {
        val contacts = getContacts(ctx)
        val lower = query.lowercase()
        // Exact match first
        contacts.firstOrNull { it.name.lowercase() == lower }?.let { return it }
        // Starts-with match
        contacts.firstOrNull { it.name.lowercase().startsWith(lower) }?.let { return it }
        // Contains match
        contacts.firstOrNull { it.name.lowercase().contains(lower) }?.let { return it }
        return null
    }

    fun findSimilarContacts(ctx: Context, query: String): List<Contact> {
        val contacts = getContacts(ctx)
        val lower = query.lowercase()
        return contacts.filter {
            it.name.lowercase().contains(lower) ||
            lower.contains(it.name.lowercase().take(4))
        }.take(3)
    }

    private fun getContacts(ctx: Context): List<Contact> {
        cache?.let { return it }
        val result = mutableListOf<Contact>()
        try {
            val cursor: Cursor? = ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
            )
            cursor?.use {
                val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (it.moveToNext()) {
                    val name = it.getString(nameIdx) ?: continue
                    val num = it.getString(numIdx) ?: continue
                    result.add(Contact(name, num.replace(Regex("[^+\\d]"), "")))
                }
            }
        } catch (e: Exception) { /* contacts permission denied */ }
        cache = result
        return result
    }

    fun clearCache() { cache = null }
}
