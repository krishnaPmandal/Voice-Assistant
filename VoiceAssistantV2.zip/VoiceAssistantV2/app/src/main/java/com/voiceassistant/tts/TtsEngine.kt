package com.voiceassistant.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Text-to-Speech wrapper.
 * Uses Android's built-in TTS — always available, no network needed.
 * Natural phrasing is handled at the ActionExecutor level.
 */
class TtsEngine(context: Context) : TextToSpeech.OnInitListener {

    private val tts = TextToSpeech(context, this)
    private var ready = false
    var onDone: (() -> Unit)? = null

    init {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { onDone?.invoke() }
            override fun onError(utteranceId: String?) { onDone?.invoke() }
        })
    }

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) tts.setLanguage(Locale.ENGLISH)
    }

    fun speak(text: String) {
        if (!ready) { onDone?.invoke(); return }
        tts.setLanguage(Locale.ENGLISH)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "va_${System.currentTimeMillis()}")
    }

    fun shutdown() = tts.shutdown()
    val isReady get() = ready
}
