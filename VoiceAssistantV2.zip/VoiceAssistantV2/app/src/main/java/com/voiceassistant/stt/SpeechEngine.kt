package com.voiceassistant.stt

import android.content.Context
import android.content.Intent
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Speech-to-Text engine wrapper.
 * Online: Google Speech Recognition (better accuracy, needs internet)
 * Offline: Falls back to Android's built-in offline recognizer
 *
 * Vosk integration point is marked with TODO for future addition.
 */
class SpeechEngine(private val context: Context) {

    interface Listener {
        fun onPartialResult(text: String)
        fun onResult(text: String)
        fun onRmsChanged(rms: Float)
        fun onError(error: String)
        fun onReady()
    }

    private var recognizer: SpeechRecognizer? = null
    private var isListening = false

    fun startListening(offline: Boolean, listener: Listener) {
        if (isListening) return
        isListening = true

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle) { listener.onReady() }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { listener.onRmsChanged(rmsdB) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                isListening = false
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "no_match"
                    SpeechRecognizer.ERROR_NETWORK -> "network_error"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "timeout"
                    SpeechRecognizer.ERROR_AUDIO -> "audio_error"
                    else -> "unknown_error"
                }
                listener.onError(msg)
            }
            override fun onResults(results: Bundle) {
                isListening = false
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull() ?: ""
                if (text.isNotBlank()) listener.onResult(text)
                else listener.onError("no_match")
            }
            override fun onPartialResults(partialResults: Bundle) {
                val matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull() ?: ""
                if (text.isNotBlank()) listener.onPartialResult(text)
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, true)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            // Prefer offline when requested
            if (offline) {
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
        }

        try {
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            isListening = false
            listener.onError("start_failed")
        }
    }

    fun stopListening() {
        isListening = false
        try { recognizer?.stopListening() } catch (_: Exception) {}
        try { recognizer?.cancel() } catch (_: Exception) {}
    }

    fun destroy() {
        stopListening()
        recognizer?.destroy()
        recognizer = null
    }

    val listening get() = isListening
}

// Android Bundle import needed
private typealias Bundle = android.os.Bundle
