package com.voiceassistant.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings

/** Resolves app names to package names and launches them safely across OEMs */
object AppLauncher {

    // System intents — work on ALL OEMs (Vivo, Samsung, Xiaomi, etc.)
    // Always checked before package-name guessing to avoid Play Store fallback
    private val SYSTEM_INTENTS: Map<String, () -> Intent> = mapOf(
        "settings" to { Intent(Settings.ACTION_SETTINGS) },
        "setting" to { Intent(Settings.ACTION_SETTINGS) },
        "wifi" to { Intent(Settings.ACTION_WIFI_SETTINGS) },
        "wi-fi" to { Intent(Settings.ACTION_WIFI_SETTINGS) },
        "bluetooth" to { Intent(Settings.ACTION_BLUETOOTH_SETTINGS) },
        "display" to { Intent(Settings.ACTION_DISPLAY_SETTINGS) },
        "sound" to { Intent(Settings.ACTION_SOUND_SETTINGS) },
        "battery" to { Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS) },
        "accessibility" to { Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS) },
        "clock" to { Intent(AlarmClock.ACTION_SHOW_ALARMS) },
        "alarm" to { Intent(AlarmClock.ACTION_SHOW_ALARMS) },
        "contacts" to { Intent(Intent.ACTION_VIEW, Uri.parse("content://contacts/people/")) },
        "phone" to { Intent(Intent.ACTION_DIAL) },
        "dialer" to { Intent(Intent.ACTION_DIAL) }
    )

    // Well-known package names
    private val APP_MAP = mapOf(
        "whatsapp" to "com.whatsapp",
        "instagram" to "com.instagram.android",
        "youtube" to "com.google.android.youtube",
        "camera" to "com.android.camera2",
        "gallery" to "com.android.gallery3d",
        "chrome" to "com.android.chrome",
        "maps" to "com.google.android.apps.maps",
        "google maps" to "com.google.android.apps.maps",
        "spotify" to "com.spotify.music",
        "facebook" to "com.facebook.katana",
        "twitter" to "com.twitter.android",
        "telegram" to "org.telegram.messenger",
        "gmail" to "com.google.android.gm",
        "calculator" to "com.android.calculator2",
        "calendar" to "com.google.android.calendar",
        "messages" to "com.android.mms",
        "snapchat" to "com.snapchat.android",
        "netflix" to "com.netflix.mediaclient",
        "amazon" to "in.amazon.mShop.android.shopping",
        "flipkart" to "com.flipkart.android",
        "paytm" to "net.one97.paytm",
        "gpay" to "com.google.android.apps.nbu.paisa.user",
        "google pay" to "com.google.android.apps.nbu.paisa.user",
        "phonepe" to "com.phonepe.app",
        "zomato" to "com.application.zomato",
        "swiggy" to "in.swiggy.android"
    )

    fun launch(context: Context, appName: String) {
        val key = appName.lowercase().trim()

        // 1. System intents first (OEM-safe)
        val sysIntent = SYSTEM_INTENTS.entries.firstOrNull { key.contains(it.key) }
        if (sysIntent != null) {
            try {
                context.startActivity(sysIntent.value().apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
                return
            } catch (_: Exception) {}
        }

        // 2. Well-known package map
        val pkg = APP_MAP.entries.firstOrNull { key.contains(it.key) }?.value
        if (pkg != null) {
            val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return
            }
        }

        // 3. Fuzzy search installed apps
        val pm = context.packageManager
        val installed = pm.getInstalledApplications(0)
        val match = installed.firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().contains(key)
        }
        if (match != null) {
            val intent = pm.getLaunchIntentForPackage(match.packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return
            }
        }

        // 4. Play Store search as last resort
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=${Uri.encode(appName)}&c=apps"))
                .apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        )
    }

    fun getInstalledWhatsApps(context: Context): List<Pair<String, String>> {
        val pm = context.packageManager
        return listOf(
            "com.whatsapp" to "WhatsApp",
            "com.whatsapp.w4b" to "WhatsApp Business",
            "com.gbwhatsapp" to "GBWhatsApp"
        ).filter { (pkg, _) ->
            try { pm.getPackageInfo(pkg, 0); true }
            catch (_: Exception) { false }
        }.map { (pkg, fallback) ->
            val label = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }
                        catch (_: Exception) { fallback }
            Pair(label, pkg)
        }
    }
}
