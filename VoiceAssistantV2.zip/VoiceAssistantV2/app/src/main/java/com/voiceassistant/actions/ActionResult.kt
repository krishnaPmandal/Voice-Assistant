package com.voiceassistant.actions

/**
 * Result from any action executor.
 * needsConfirmation = true → show confirm bar before executing
 * action = the thing to actually run (after confirmation if needed)
 */
data class ActionResult(
    val reply: String,
    val action: (() -> Unit)? = null,
    val needsConfirmation: Boolean = false,
    val confirmationPrompt: String = "",
    val pendingAction: (() -> Unit)? = null,   // runs after user says Yes
    val needsFollowUp: Boolean = false,
    val followUpPrompt: String = ""
)
