package com.voiceassistant.core

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.voiceassistant.actions.ActionExecutor
import com.voiceassistant.actions.ActionResult
import com.voiceassistant.data.AssistantPrefs
import com.voiceassistant.nlu.IntentParser
import com.voiceassistant.stt.SpeechEngine
import com.voiceassistant.tts.TtsEngine

/**
 * Central orchestrator — ties STT → NLU → Action → TTS together.
 * Architecture: Wake → STT → NLU → Action → TTS (spec item 13).
 * Handles context, confirmation flow, and continuous listening loop.
 */
class AssistantEngine(private val ctx: Context) {

    interface Listener {
        fun onListeningStart()
        fun onPartialText(text: String)
        fun onResponseReady(result: ActionResult, spokenText: String)
        fun onAmplitude(amp: Float)
        fun onError(message: String)
        fun onStateChange(state: State)
    }

    enum class State { IDLE, LISTENING, PROCESSING, SPEAKING }

    private val stt = SpeechEngine(ctx)
    private val tts = TtsEngine(ctx)
    private val handler = Handler(Looper.getMainLooper())

    private var listener: Listener? = null
    private var state = State.IDLE
    private var pendingFollowUp = ""     // multi-turn context
    private var pendingConfirmation: ActionResult? = null  // spec item 7
    private var isRunning = false

    fun setListener(l: Listener) { listener = l }

    fun start() { isRunning = true; listen() }

    fun stop() {
        isRunning = false
        stt.stopListening()
        tts.stop()
        setState(State.IDLE)
    }

    fun shutdown() {
        stop()
        stt.destroy()
        tts.shutdown()
    }

    private fun listen() {
        if (!isRunning) return
        setState(State.LISTENING)
        listener?.onListeningStart()

        stt.startListening(object : SpeechEngine.Listener {
            override fun onPartialResult(text: String) { listener?.onPartialText(text) }
            override fun onAmplitude(rms: Float)       { listener?.onAmplitude(rms) }
            override fun onResult(text: String)        { onSpokenInput(text) }
            override fun onError(message: String) {
                setState(State.IDLE)
                if (message == "no_match") {
                    speakThenListen("Please say again.")
                } else {
                    speakThenListen(message)
                }
            }
        })
    }

    private fun onSpokenInput(text: String) {
        setState(State.PROCESSING)

        // Handle confirmation flow (spec item 7)
        if (pendingConfirmation != null) {
            handleConfirmation(text)
            return
        }

        // Handle multi-turn follow-up
        val fullText = if (pendingFollowUp.isNotBlank()) "$pendingFollowUp:$text" else text

        val parsed = IntentParser.parse(ctx, text)
        val result = ActionExecutor.execute(ctx, parsed)

        pendingFollowUp = if (result.needsFollowUp) result.followUpContext else ""

        AssistantPrefs.saveHistory(ctx, text, result.spokenReply)
        listener?.onResponseReady(result, result.spokenReply)

        if (result.needsConfirmation) {
            pendingConfirmation = result
            speakThenListen(result.confirmationPrompt)
        } else {
            speakThenListen(result.spokenReply) { result.action?.invoke() }
        }
    }

    private fun handleConfirmation(text: String) {
        val lower = text.lowercase()
        val confirmed = lower.containsAny("yes", "yeah", "sure", "ok", "okay",
            "do it", "go ahead", "confirm", "yep", "absolutely")
        val pending = pendingConfirmation
        pendingConfirmation = null

        if (confirmed && pending != null) {
            speakThenListen(pending.spokenReply) { pending.action?.invoke() }
        } else {
            speakThenListen("Okay, cancelled.")
        }
    }

    private fun speakThenListen(text: String, beforeListen: (() -> Unit)? = null) {
        setState(State.SPEAKING)
        tts.speak(text) {
            handler.post {
                beforeListen?.invoke()
                handler.postDelayed({
                    if (isRunning) listen()
                }, 600)
            }
        }
    }

    private fun setState(s: State) { state = s; listener?.onStateChange(s) }

    private fun String.containsAny(vararg kw: String) = kw.any { this.contains(it) }
}
