package com.voiceassistant.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.voiceassistant.data.Prefs
import com.voiceassistant.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.etAssistantName.setText(Prefs.getAssistantName(this))
        if (Prefs.isOfflineMode(this)) binding.rbOffline.isChecked = true
        else binding.rbOnline.isChecked = true
        binding.switchConfirmCalls.isChecked = Prefs.isConfirmCalls(this)
        binding.switchConfirmSms.isChecked = Prefs.isConfirmSms(this)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnSave.setOnClickListener {
            val name = binding.etAssistantName.text?.toString()?.trim()
            if (!name.isNullOrBlank()) Prefs.setAssistantName(this, name)
            Prefs.setOfflineMode(this, binding.rbOffline.isChecked)
            Prefs.setConfirmCalls(this, binding.switchConfirmCalls.isChecked)
            Prefs.setConfirmSms(this, binding.switchConfirmSms.isChecked)
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
